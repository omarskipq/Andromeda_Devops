
import constants
url = constants.URLS_TO_MONITER
def health_web():
  return {
      "url":"it worked"
  }